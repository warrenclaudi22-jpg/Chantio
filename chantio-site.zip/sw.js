// Service worker de Chantio : ouverture rapide et fonctionnement de base hors connexion.
// Les données de l'utilisateur ne sont jamais mises en cache ici (elles passent par Supabase).
const CACHE = 'chantio-v1';
const SHELL = ['./', 'index.html', 'config.js', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => Promise.allSettled(SHELL.map((u) => c.add(u)))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
const keep = (req, res) => { if (res && (res.ok || res.type === 'opaque')) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); } return res; };
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (/supabase\.(co|in)$/.test(url.hostname)) return;
  if (url.origin === location.origin) {
    e.respondWith(fetch(req).then((res) => keep(req, res)).catch(() => caches.match(req).then((r) => r || caches.match('index.html'))));
  } else if (/(jsdelivr|cdnjs|googleapis|gstatic)/.test(url.hostname)) {
    e.respondWith(caches.match(req).then((hit) => {
      const net = fetch(req).then((res) => keep(req, res)).catch(() => hit);
      return hit || net;
    }));
  }
});
